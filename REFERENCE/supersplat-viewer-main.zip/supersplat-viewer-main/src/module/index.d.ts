export const html: string;
export const css: string;
export const js: string;
