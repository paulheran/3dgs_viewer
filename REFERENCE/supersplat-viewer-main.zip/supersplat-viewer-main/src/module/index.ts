import css from '../../public/index.css';
import html from '../../public/index.html';
import js from '../../public/index.js';

export { html, css, js };
